
const {Customer} = require("../class/customer.js");


class PremiumCustomer extends Customer {
    constructor(name) {
        super(name);
        this.money = 5;
        this.purchases = []
      }

    //   super 
    


}






module.exports ={

    PremiumCustomer,

};