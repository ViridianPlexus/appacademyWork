
class Customer{
    constructor(name) {
      this.name = name;
      this.money = 0;
      this.purchases = []
    }
    addFunds(sum){

        this.money +=sum;

        // return this.money

    }

    addItem(item){

        this.purchases.push(item)

        // return this.money

    }

    withdrawFunds(amount){

        // console.log(amount == this.money )

        // console.log((amount))
        // console.log((this.money))
        // console.log(typeof(amount))
        // console.log(typeof(this.money))

        if(this.money>=amount){
            
            this.money -=amount;

            return 
        }
        //  console.log('made it out')

    
        if(this.money<amount)
            {
                console.log('were in')
                throw new Error;

            }
       
        // console.log('made it past')
    }
   
  }





module.exports ={

    Customer,

};
