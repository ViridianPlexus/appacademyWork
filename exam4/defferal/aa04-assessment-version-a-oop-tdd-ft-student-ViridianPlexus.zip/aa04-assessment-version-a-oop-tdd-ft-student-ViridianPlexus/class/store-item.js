

class StoreItem{
    constructor(name, price) {
      this.name = name;
      this.price = price;
     
    }

    isValid(){

        if(this.name === undefined || this.price <=0 || this.price ===undefined){
            return false;
        }else{
            return true;
        }

    }


    
  static compareItems(StoreItem1,StoreItem2){

        if(StoreItem1.price<StoreItem2.price){
            return StoreItem1;
        }else if(StoreItem1.price>StoreItem2.price){
            return StoreItem2;
        }



    }

static sumItems(...ok){

    let sum = 0

    for(let x =0; x<ok.length; x++){
        sum += ok[x].price;
    }

    return sum;

}
 
   
  }
  


module.exports ={

    StoreItem,

};
