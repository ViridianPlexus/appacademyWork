const {PremiumCustomer} = require("../class/premium-customer.js");



class Store{
    constructor(name, price) {
      this.name = name;
      this.price = 0;
      this.items = []
    }


     addItem(le_class){


        if(le_class.price<=0){
            throw new Error
        }else{
        this.items.push(le_class)}
        
    }

    getStoreItemPrices(){

        let keyvals = this.items.map( obj => {
            let [key, val] = Object.entries(obj);
            return `${key[1]}: $${val[1]}`
        });
        
        return keyvals;
    }

    doTransaction(custy, item_name){

        if(custy.constructor === PremiumCustomer ){

         

            if(item_name ==='Mug'){
                custy.withdrawFunds(2); 
                custy.addItem('Mug')
            }
            else if(item_name ==='Chair'){
                
                custy.withdrawFunds(9);
                
                custy.addItem('Chair')
            
            }
            else if(item_name ==='Table'){
                
                // console.log('were in table!!!!')

                custy.withdrawFunds(19);

                // console.log('hello!!!!')
                // console.log('herera' + custy.money)
                custy.addItem('Table')
            }
            else{
                throw new Error
            }
    

        }
        else{

        if(item_name ==='Mug'){
            custy.withdrawFunds(3); 
            custy.addItem('Mug')
        }
        else if(item_name ==='Chair'){
            
            custy.withdrawFunds(10);
            
            custy.addItem('Chair')
        
        }
        else if(item_name ==='Table'){
            custy.withdrawFunds(20);
            custy.addItem('Table')
        } else{
            throw new Error
        }

    }

}

    
   
  }



  module.exports ={

    Store,

};