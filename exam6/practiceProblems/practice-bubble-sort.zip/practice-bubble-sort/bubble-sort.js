
function bubbleSort(arr) {

  // console.log('the arr we have: ' + arr)

    // Iterate through the array
    let i =0
    let swapped;

    // console.log(arr.join(","));
    do{
      
      swapped = false;  // Reset swapped to false at the beginning of each iteration
      for (let i = 0; i < arr.length - 1; i++) {  // Iterate through the array


        
        if (arr[i] > arr[i + 1]) { 
          // Swap those values
          [arr[i], arr[i + 1]] = [arr[i + 1], arr[i]];
          swapped = true;  // Set swapped to true if a swap occurred
      }
      console.log(arr.join(","));
          // Do not move this console.log
         

           // If the current value is greater than its neighbor to the right
        
      }
      // If no swaps occurred, the array is sorted and we can exit the loop

      // 2,4,6,8,1,3,5,7,9

    }while(swapped)
    
      // console.log('final: ' + arr)
      return arr;
}




module.exports = bubbleSort;